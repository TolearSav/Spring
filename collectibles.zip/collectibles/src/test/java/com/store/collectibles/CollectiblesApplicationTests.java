package com.store.collectibles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollectiblesApplicationTests {

	@Test
	void contextLoads() {
	}

}
